package com.example.wonder_pass;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static java.security.AccessController.getContext;

public class LoginActivity extends AppCompatActivity {

    private String url = "http://wonderpass.co.kr/app_login_check.php"; //연결할 웹서버 주소
    private ContentValues values = new ContentValues();

    TextInputEditText TextInputEditText_ID,  TextInputEditText_password;
    LinearLayout LinearLayout_login;

    String inputId = "";
    String inputPassword = "";
    String isCheckTrue = "";
    String mserial_num = "";
    boolean isIdnull = false;
    boolean isPwnull = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        TextInputEditText_ID = findViewById(R.id.TextInputEditText_ID);
        TextInputEditText_password = findViewById(R.id.TextInputEditText_password);
        LinearLayout_login = findViewById(R.id.LinearLayout_login);

        LinearLayout_login.setClickable(false);
        TextInputEditText_ID.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                if (charSequence != null) {
                    //null이 아닐때만(값이 들어있으면) id를 스트링으로 받는다.
                    inputId = charSequence.toString();
                    //LinearLayout_login.setEnabled(true);
                    isIdnull = true;
                }

            }
            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        TextInputEditText_password.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                //입력한 pw가 null이 아니면 pw를 받아라
                if(charSequence != null) {
                    inputPassword = charSequence.toString();
                    //LinearLayout_login.setEnabled(true);
                    isPwnull = true;
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        LinearLayout_login.setEnabled(true);
        LinearLayout_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String id = TextInputEditText_ID.getText().toString();
                String password = TextInputEditText_password.getText().toString();

                if(isIdnull == false){
                    Toast.makeText(getApplicationContext(), "아이디를 입력하세요.", Toast.LENGTH_SHORT).show();
                }
                else if(isPwnull == false){
                    Toast.makeText(getApplicationContext(), "비밀번호를 입력하세요.", Toast.LENGTH_SHORT).show();
                }
                if(isIdnull == true && isPwnull == true){
                    values.put("USERID", id); //여기서 앱에서 웹서버로 전달할 값을 넣음
                    values.put("APPPW", password); //여기서 앱에서 웹서버로 전달할 값을 넣음
                    NetworkTask networkTask = new NetworkTask(url, values); //앱이랑 웹서버랑 연결
                    networkTask.execute();
                }
            }
        });
    }

    public class NetworkTask extends AsyncTask<Void, Void, String> {

        private String url;
        private ContentValues values;

        public NetworkTask(String url, ContentValues values) {

            this.url = url;
            this.values = values;
        }

        @Override
        protected String doInBackground(Void... params) {

            String result; // 요청 결과를 저장할 변수.
            RequestHttpConnection requestHttpConnection = new RequestHttpConnection();
            result = requestHttpConnection.request(url, values); // 해당 URL로 부터 결과물을 얻어온다.

            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            doJSONParser(s);
            //doInBackground()로 부터 리턴된 값이 onPostExecute()의 매개변수로 넘어오므로 s를 출력한다.
            System.out.println(isCheckTrue);
            if(isCheckTrue.equals("true")){
                String id = TextInputEditText_ID.getText().toString();
                String password = TextInputEditText_password.getText().toString();
                System.out.println(isCheckTrue);
                // 여기(MA)에서 MainActivity클래스로 넘긴다.
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                intent.putExtra("WP_ID", id);
                intent.putExtra("serial_num", mserial_num);
                startActivity(intent);
            }
            else{
                Toast.makeText(getApplicationContext(), "잘못된 아이디 혹은 비밀번호입니다.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    void doJSONParser(String str){
        try{
            String result = "";
            String serial_num = "";
            JSONObject order = new JSONObject(str);
            JSONArray index = order.getJSONArray("webnautes");
            for (int i = 0; i < index.length(); i++) {
                JSONObject tt = index.getJSONObject(i);
                result += tt.getString("check");
                serial_num = tt.getString("serial_num");
            }
            isCheckTrue = result;
            System.out.println(isCheckTrue);
            mserial_num = serial_num;
        }
        catch (JSONException e){ ;}
    }
}