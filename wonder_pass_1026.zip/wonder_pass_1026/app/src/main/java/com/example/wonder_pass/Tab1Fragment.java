package com.example.wonder_pass;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import java.sql.*;
import java.util.Date;
import java.util.Locale;

public class Tab1Fragment extends Fragment {

    private String url = "http://wonderpass.co.kr/doLoop.php";
    private ContentValues values = new ContentValues();
    private static final String TAG = "Tab1Fragment";

    private ArrayList<String> numArray;
    private int std_time;

    String PW = null;
    private String appid;
    private int serial_num;
    private long index_diff;
    private long cur_index;
    private long countdown;
    private String display_pw;
    private Tab1Fragment mViewModel;

    public static Tab1Fragment newInstance() {
        return new Tab1Fragment();
    }

    private TextView password;
    private TextView _background;
    private TextView timer_text;
    private CountDownTimer _timer;
    private Button button1;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.tab1_password, container, false);

        if(getArguments() != null){
            serial_num = Integer.parseInt(getArguments().getString("serial_num"));
        }

        if(getArguments() != null){
            appid = getArguments().getString("inputId");
        }

        System.out.println(serial_num);
        System.out.println(appid);

        password = (TextView) view.findViewById(R.id.textView2);
        _background = (TextView) view.findViewById(R.id.textBackground);
        timer_text = (TextView) view.findViewById(R.id.time_second);

        numArray = new ArrayList<String>();
        numArray.add("05060505237");
        numArray.add("05060505743");
        numArray.add("05060506198");
        numArray.add("05060506564");
        numArray.add("05060507223");
        numArray.add("05060507694");
        numArray.add("05060508382");
        numArray.add("05060509382");
        numArray.add("05060509593");


//        final Handler han = new Handler(){
//            @Override
//            public void handleMessage(@NonNull Message msg) {
//                super.handleMessage(msg);
//                timer_text.setText(msg.arg1+"");
//            }
//        };
//
//        Thread th = new Thread(new Runnable() {
//            @Override
//            public void run() {
//                while(true){
//                    Message msg = han.obtainMessage();
//                    countdown--;
//                    msg.arg1 = (int)countdown;
//                    if(countdown == 0){
//                        countdown = 30;
//                    }
//                    han.sendMessage(msg);
//                    try{
//                        Thread.sleep(1000);
//                    }catch(InterruptedException e){
//                        e.printStackTrace();
//                    }
//                }
//            }
//        });
//        th.start();

        button1 = (Button) view.findViewById(R.id.button_print);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _background.setVisibility(View.VISIBLE);
                curTime();
//                values.put("Display_PW", display_pw);
                values.put("WP_ID", appid);
                NetworkTask networkTask = new NetworkTask(url, values);
                networkTask.execute();
            }
        });

        final Button button2 = (Button) view.findViewById(R.id.button_copy);
        button2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                ClipboardManager clipboard = (ClipboardManager)getContext().getSystemService(getContext().CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("label", password.getText());
                clipboard.setPrimaryClip(clip);
                Toast.makeText(getContext(), "클립보드에 복사되었습니다.", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }

    public class NetworkTask extends AsyncTask<Void, Void, String> {

        private String url;
        private ContentValues values;

        public NetworkTask(String url, ContentValues values) {

            this.url = url;
            this.values = values;
        }

        @Override
        protected String doInBackground(Void... params) {

            String result; // 요청 결과를 저장할 변수.
            RequestHttpConnection requestHttpConnection = new RequestHttpConnection();
            result = requestHttpConnection.request(url, values); // 해당 URL로 부터 결과물을 얻어온다.

            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            doJSONParser(s);
        }
    }

    void doJSONParser(String str){
        try{
            String result = "";

            JSONObject order = new JSONObject(str);
            JSONArray index = order.getJSONArray("webnautes");
            for (int i = 0; i < index.length(); i++) {
                JSONObject tt = index.getJSONObject(i);
                result +=  tt.getString("number");
            }
        }
        catch (JSONException e){ ;}
    }

    void curTime(){
        String std_date = "20191115113000";
        Date cur_date = new Date();
        SimpleDateFormat timeSet = new SimpleDateFormat("yyyyMMddHHmmss", Locale.KOREA);
        SimpleDateFormat secSet = new SimpleDateFormat("ss", Locale.KOREA);
        long now = System.currentTimeMillis();

        Date tt = new Date(now);
        SimpleDateFormat ttt = new SimpleDateFormat("ss", Locale.KOREA);
        String strNow = ttt.format(tt);
        int cur_sec = Integer.parseInt(strNow) - 2;

        System.out.println("cur_sec = " + cur_sec);

        try{
            Date std_d = timeSet.parse(std_date);
            long std_time = std_d.getTime();

            cur_date = timeSet.parse(timeSet.format(cur_date));
            long cur_time = cur_date.getTime();

            long diff = (cur_time - std_time) / 1000;

            index_diff = (diff/30)%9;

            if(cur_sec<=30)
                countdown = 30-cur_sec;
            else
                countdown = 60-cur_sec;

            printNum();

        }catch(ParseException e){
            e.printStackTrace();
        }
    }

    void printNum(){
        switch(serial_num){
            case 1:
                cur_index = index_diff+ 2;
                break;
            case 2:
                cur_index = index_diff+ 5;
                break;
            case 3:
                cur_index = index_diff+ 8;
                break;
        }
        if(cur_index > 9){
            long temp = cur_index % 9;
            if(temp==0)
                cur_index = 9;
            else
                cur_index = temp;
        }
        display_pw = numArray.get((int)cur_index);
        password.setText(display_pw);
    }
}
