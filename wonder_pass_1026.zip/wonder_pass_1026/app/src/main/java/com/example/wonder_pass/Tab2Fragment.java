package com.example.wonder_pass;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toolbar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class Tab2Fragment extends Fragment {
    private static final String TAG = "Tab2Fragment";
    private TextView tv1, tv2, tv3, tv4, tv5;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.tab2_sitelink,container,false);

//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.tab4_change_pw);

      //  Toolbar myToolbar = view.findViewById(R.id.my_toolbar);
//        setSupportActionBar(myToolbar);
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
       // ((MainActivity) getActivity()).setTitle("비밀번호 변경");
        // 뒤로가기 버튼, 디폴트로 true만 해도 백버튼이 생김
       // ((MainActivity) getActivity()).setDisplayHomeAsUpEnabled(true);

        tv1 = (TextView) view.findViewById(R.id.button_naver);
        tv1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://wonderpass.co.kr"));
                startActivity(intent);
            }
        });

        tv2 = (TextView) view.findViewById(R.id.button_daum);
        tv2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.daum.net"));
                startActivity(intent);
            }
        });

        tv3 = (TextView) view.findViewById(R.id.button_11st);
        tv3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.11st.co.kr"));
                startActivity(intent);
            }
        });

        tv4 = (TextView) view.findViewById(R.id.button_cgv);
        tv4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.cgv.co.kr"));
                startActivity(intent);
            }
        });

        tv5 = (TextView) view.findViewById(R.id.button_google);
        tv5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.google.com"));
                startActivity(intent);
            }
        });
        return view;
    }


}
