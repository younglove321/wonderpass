<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>  

<?php
	$connect = mysqli_connect("database-wonder-pass.cd4ojvi0nivs.ap-northeast-2.rds.amazonaws.com", "wonderpass", "dnjsej10", "wonder_pass");

	// wplogin_second_form.php에서 입력받은 정보 가져오기
	$passwd = $_POST["050pw"]; //입력받은 050 passwd

	// 알고리즘!!
	// 입력받은 값이 050 비밀번호와 일치하는지 확인 
	date_default_timezone_set('Asia/Seoul');
	$cur_min = date("i");
	$cur_sec = date("s");
	
	$min = $cur_min % 6;
	$sec = $cur_sec;

	switch($min){

	case 0:
		if($sec>=1 && $sec<41)
			$index = array(2,5,8);
		elseif($sec>=41 && $sec<60)
			$index = array(3,6,9);
			break;

	case 1:
		if($sec>=0 && $sec<21)
			$index = array(3,6,9);
		elseif($sec>=21 && $sec<61)
			$index = array(4,7,1);
			break;

	case 2:
		if($sec>=1 && $sec<41)
			$index = array(5,8,2);
		elseif($sec>=41 && $sec<60)
			$index = array(6,9,3);
			break;

	case 3:
		if($sec>=0 && $sec<21)
			$index = array(6,9,3);
		elseif($sec>=21 && $sec<61)
			$index = array(7,1,4);
			break;

	case 4:
		if($sec>=1 && $sec<41)
			$index = array(8,2,5);
		elseif($sec>=41 && $sec<60)
			$index = array(9,3,6);
			break;

	case 5:
		if($sec>=0 && $sec<21)
			$index = array(9,3,6);
		elseif($sec>=21 && $sec<61)
			$index = array(1,4,7);
			break;
	}

	
	// m1, m2, m3 : 사람 1 ,2 , 3
	// if문은 시작과 끝 인덱스를 후보정 해주는 부분
	
	$before_m1 = $index[0] - 1; 
	$now_m1 = $index[0]; // 현재 050번호 인덱스
	$after_m1 = $index[0] + 1;

	$before_m2 = $index[1] - 1;
	$now_m2 = $index[1];
	$after_m2 = $index[1] + 1;

	$before_m3 = $index[2] - 1;
	$now_m3 = $index[2];
	$after_m3 = $index[2] + 1;

	// 앱에서 로그인 한 사용자 식별 번호 가져오기 (누가 로그인 했는지)
	$mem_serial = $_POST['Serial_num']; 

	session_start(); // 세션을 사용할 수 있도록 설정한다.

	// Serial_num이 POST 방식으로 넘어오지 않으면 exit
	if(isset($_POST['Serial_num'])) 
	{
		echo "$mem_serial";
	}
	else
	{
		echo "<script>alert('사용자 정보를 확인할 수 없습니다.'); history.back(); </script>";
		exit;
	}


	$user_sql = "
		SELECT *
		FROM MEM 
		WHERE MEM_SERIAL = '$mem_serial' 
		"; 
	$user_result = mysqli_query($connect, $user_sql); // 쿼리를 실행한 후 결과 셋이 result에 리턴된다.
	$user_row = mysqli_fetch_array($user_result); // 레코드를 가져온다.
	
	$user_name = $user_row[MEM_NAME];
	$user_id = $user_row[USERID];
	
	echo $mem_serial;
	echo $user_id;


	// 입력 받은 050 비밀번호가 존재하는지 확인
	$sql = "SELECT * 
			FROM 050RES
			WHERE 050_RES = '$passwd'
			";
	$statement = mysqli_query($connect, $sql) or die(mysqli_error($connect));
	$row = mysqli_fetch_array($statement);
	$recordcount = mysqli_num_rows($statement); // 레코드 개수
	
	
	if ($recordcount == 1)
	{
		// 세션 변수에 값을 저장한다.
		// 웹브라우저가 종료되거나 사용자가 로그아웃할 때까지 값이 저장된다.
		// 세션 변수는 로그인 정보를 필요로 하는 여러 기능에서 사용된다.
		$_SESSION['user_name'] = $user_name; // 이름
		$_SESSION['user_id'] = $user_id;  // 아이디

		echo "<script> location.href='send_sms_action.php'; </script>";
	}
	else
		echo "<script> alert('비밀번호가 일치하지 않습니다.'); history.back(); </script>";
?>
</body>
</html>