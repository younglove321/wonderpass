<?php
$link = mysqli_connect("localhost", "wonderpass", "dnjsej10!", "wonderpass");  

if (!$link)
{  
    echo "MySQL 접속 에러 : ";
    echo mysqli_connect_error();
    exit();  
}  

mysqli_set_charset($link,"utf8"); 

$id=$_POST['USERID'];
$pw=$_POST['APPPW'];

$sql = "SELECT * FROM MEM WHERE USERID = '$id' AND APPPW = '$pw'";

$result=mysqli_query($link,$sql);
$data = array();
if($result){
	while($row=mysqli_fetch_array($result)){
		array_push($data, array('check' => "true", 'serial_num' => $row[5]));
	}
}


header('Content-Type: application/json; charset=utf8');
$json = json_encode(array("webnautes"=>$data), JSON_PRETTY_PRINT+JSON_UNESCAPED_UNICODE);
echo $json;
mysqli_close($link);
?>