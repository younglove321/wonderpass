<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
</head>
<body>

<?php

	$connect = mysqli_connect("database-wonder-pass.cd4ojvi0nivs.ap-northeast-2.rds.amazonaws.com", "wonderpass", "dnjsej10", "wonder_pass");

	// wplogin_second_form.php에서 입력받은 정보 가져오기
	$input_pw = $_POST['2stepnum']; //입력받은 2단계 pw
	$secondpw = $_POST['secondpw']; //2단계인증 ps (일단 임시로 정해놓은 것)
  
	$str = strcmp($input_pw, $secondpw);
    if($str){
?>
    <script type="text/javascript">
    alert("2단계 인증 성공"); //로그인에 성공하면 성공했다는 메세지를 띄우고 
    location.href="wplogin_result.php"; //고객의 main페이지로 이동한다.
    </script>
<?php
   } 
	else{
?>
    <script type="text/javascript">
    alert("2단계 인증 번호가 잘못되었습니다 다시 입력해주세요.");
    history.back();
    </script> 
<?php 
	} 
?>
</body>
</html>



