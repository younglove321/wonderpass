<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<body>  
<?php
//2단계 인증을 하는 경우
$connect = mysqli_connect("database-wonder-pass.cd4ojvi0nivs.ap-northeast-2.rds.amazonaws.com", "wonderpass", "dnjsej10", "wonder_pass");

// LoginForm.php에서 입력받은 정보 가져오기
// POST 방식으로 넘어오지 않으면 exit
if(!isset($_POST['050pw'])) {
	echo "<script>alert('비밀번호를 입력하세요.'); history.back(); </script>";
	exit;
}
$passwd = $_POST["050pw"]; // 입력받은 050 passwd
$secondpw = mt_rand(1001, 9999); // 문자로 보내줄 2단계인증 pw
?>


<?php
// 입력받은 050 전화번호로 2단계 인증 비즈메시지 보내기 
$sql = "INSERT INTO TBL_SUBMIT_QUEUE 
VALUES ( 1, '1', '3135', '1', '00', 'I', CAST(DATE_FORMAT(now(),'%Y%m%d%H%i%s') AS CHAR),  '1', '$passwd', '01022007103', '', '00', '$secondpw', '', 0, '', '', CAST(DATE_FORMAT(now(),'%Y%m%d%H%i%s') AS CHAR), '', '', '', '', '0', '', '', '', '', '', '', '', 0, 0)";

$result = mysqli_query($connect, $sql) or die(mysqli_error($connect));

echo "<script>alert('문자메세지를 발신했습니다'); </script>";

echo "<form method='POST' action=wplogin_2step_form.php>";
echo "<input type=hidden name=secondpw value=$secondpw>";
echo "</form>";

echo "<script>location.href='wplogin_2step_form.php'</script>";
?>

</body>
</html>