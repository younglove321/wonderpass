<!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, user-scalable=no">
  <link rel="stylesheet" type="text/css" href="reset.css"> 
  <title>Naver</title>
  <style>
     body {
	            background:url('image\naverwp.png');
				position : relative;  
				background-repeat:no-repeat;
				background-size: cover;
		    }
   </style>
 </head>
 <body>
 <h2>원더패스 로그인 성공</h2>
 </body>
</html>