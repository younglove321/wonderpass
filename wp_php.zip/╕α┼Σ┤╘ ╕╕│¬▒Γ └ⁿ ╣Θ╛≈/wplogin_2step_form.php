<!-- wplogin_2step_form.php 2단계인증 -->    
<!doctype html>
<html lang="en">
 <head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Login</title>
  <style>
  @import url(https://fonts.googleapis.com/css?family=Roboto:300);

.login-page {
  width: 360px;
  padding: 8% 0 0;
  margin: auto;
}
.form {
  position: relative;
  z-index: 1;
  background: #FFFFFF;
  max-width: 360px;
  margin: 0 auto 100px;
  padding: 45px;
  text-align: center;
  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
}
.form input {
  font-family: "Roboto", sans-serif;
  outline: 0;
  background: #f2f2f2;
  width: 100%;
  border: 0;
  margin: 0 0 15px;
  padding: 15px;
  box-sizing: border-box;
  font-size: 14px;
}
.form button {
  font-family: "Roboto", sans-serif;
  text-transform: uppercase;
  background: #FF9999;
  outline: 0;
  width: 100%;
  border: 0;
  padding: 15px;
  color: #FFFFFF;
  font-size: 14px;
  -webkit-transition: all 0.3 ease;
  transition: all 0.3 ease;
  cursor: pointer;
  border-top-right-radius: 5px; 
  border-bottom-right-radius: 5px;
  border-top-left-radius: 5px; 
  border-bottom-left-radius: 5px;
}
.form button:hover,.form button:active,.form button:focus {
  background: #FF0000;
}
.form .message {
  margin: 15px 0 0;
  color: #b3b3b3;
  font-size: 12px;
}
.form .message a {
  color: #4CAF50;
  text-decoration: none;
}

.container {
  position: relative;
  z-index: 1;
  max-width: 300px;
  margin: 0 auto;
}
.container:before, .container:after {
  content: "";
  display: block;
  clear: both;
}
.container .info {
  margin: 50px auto;
  text-align: center;
}
.container .info h1 {
  margin: 0 0 15px;
  padding: 0;
  font-size: 36px;
  font-weight: 300;
  color: #1a1a1a;
}
.container .info span {
  color: #4d4d4d;
  font-size: 12px;
}
.container .info span a {
  color: #000000;
  text-decoration: none;
}
.container .info span .fa {
  color: #EF3B3A;
}

body {
  background: #76b852; /* fallback for old browsers */
  background: -webkit-linear-gradient(right, #76b852, #8DC26F);
  background: -moz-linear-gradient(right, #76b852, #8DC26F);
  background: -o-linear-gradient(right, #76b852, #8DC26F);
  background: linear-gradient(to left, #76b852, #8DC26F);
  font-family: "Roboto", sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;      
}
  </style>
 </head>

 <body>
  <div class="login-page">
  <div class="form">
      <img src="image\logo.PNG" align="middle">
      <p class="message" >Already registered? <a href="#">Sign In</a></p>
<?php
$secondpw = $_POST['secondpw'];
?>

    <form class="login-form" action="ok_sms_action.php" method="post">

      <input type="text" name="2stepnum" placeholder="2단계 인증번호 입력"/>
      <button type = "submit" >로그인</button>
      <p class="message">전송된 문자의 인증번호를 입력하세요!</p>
   
	  <input type="hidden" name="secondpw" value="$secondpw">


    </form>
  </div>
</div>
 </body>
</html>
